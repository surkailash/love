# Love-Calculator
<p>Let's Calculate love with real data. Love Calculator by Mohammed Cha</p>
<strong>Love-Calculator</strong> is a small web application encoded in <code>HTML</code>, <code>PHP</code>, <code>JS</code>, and <code>CSS</code>.
</br></br>
<b><a href="http://love.freevar.com" >DEMO HERE</a></b>
