<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->

<html>
	<?php require_once ('inc/head.php')?>
<body>
	<?php require_once ('inc/menu.php')?>
	<div class="container">
		<div class="intro">
			<a href="./"><img width="120px" src="assets/love.png" /></a>
			<h1>About Us</h1>
			<p><b>Love Meter</b> to Calculate Love Percentage</p>
		</div>
		<div class="pages">

		
		<!--------	About	-------->
		<p>
			We all know that a name can tell a lot about a person.<br />
			Names are not randomly chosen: they all have a meaning.<br />
			Love Calculator knew this so he made another great invention just for the lonely you!<br />
			Sometimes you'd like to know if a relationship with someone could work out.<br />
			Therefore Love Calculator himself designed this great machine for you.
		</p>
		<p>
			With The Love Calculator you can calculate the probability of a successful relationship between two people.<br />
			The Love Calculator is an affective way to get an impression of what the chances are on a relationship between two people.
		</p>
		<!--------	END About	-------->


		</div>
	</div>	
<?php require_once ('inc/footer.php')?>		
</body>
</html>

<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->