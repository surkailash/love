<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->

<html>
	<?php require_once ('inc/head.php')?>
<body>
	<?php require_once ('inc/menu.php')?>
	<div class="container">
		<div class="intro">
			<a href="./"><img width="120px" src="assets/love.png" /></a>
			<h1>Contact Us</h1>
			<p><b>Love Meter</b> to Calculate Love Percentage</p>
		</div>
		<div class="pages">


		<!--------	Contact	-------->
			<p>Need help?</p>
			<b>Please email us at: </b> <code>contact@gmail.com</code>
		<!--------	END Contact	-------->

		
		</div>
	</div>	
<?php require_once ('inc/footer.php')?>		
</body>
</html>

<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->