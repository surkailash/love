<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->

<footer>
	<div class="footer">
		<a href="faqs.php">FAQ's</a>	
		<a href="privacy_policy.php">Privacy Policy</a>
		<a href="terms_conditions.php">Terms of use</a>
	</div>

	<div class="footer">
		<p>
			<a target="_blank" href="https://web.facebook.com/spidernichetool">Mohammed Cha</a> © 2019 </br> </br> 
			Honorable Mention ❤️ Re-skinning Group
		</p>
	</div>

</footer>	

<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->