<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->

<html>
	<?php require_once ('inc/head.php')?>
<body>
	<?php require_once ('inc/menu.php')?>
	<div class="container">
		<div class="intro">
			<a href="./"><img width="120px" src="assets/love.png" /></a>
			<h1>Terms of Use</h1>
			<p><b>Love Meter</b> to Calculate Love Percentage</p>
		</div>
		<div class="pages">


		<!--------	Terms of Use	-------->
			<p>When you use the Love Calculator,
			all entered data will be transmitted to the owner of the Love Calculator 
			or owner of this site is not responsible for any misuse of data entered by you. </p>
			<b>If you do not agree to this, please do not fill in anything. </b>
			<p>By accessing this website and/or the use of the service therein, you expressly permit, 
			authorize and give consent to the Love Calculator website to share information about you or provided by you to any third party.</p>
		<!--------	END Terms of Use	-------->

		
		</div>
	</div>	
<?php require_once ('inc/footer.php')?>		
</body>
</html>

<!--
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
-->

