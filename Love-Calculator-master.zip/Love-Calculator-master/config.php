<?php 
/*
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
*/

$site_name = "Love Calculator | Love Meter to Calculate Love Percentage"; 
$site_url = "http://love.freevar.com";

/***   google adsense validation ID    ***/
$adsense_validation = "ca-pub-XXXXXXXXXXXXXXXX";


/***   data ad client small   ***/
$small_ads_id = "ca-pub-XXXXXXXXXXXXXXXX";
$small_ads_slot = "XXXXXXXXXX";
          

/***   data ad client big    ***/
$big_ads_id = "ca-pub-XXXXXXXXXXXXXXXX";
$big_ads_slot = "XXXXXXXXXX";

/***   google analytics ID    ***/
$analytics_tracking = "UA-XXXXXXXXX-1";

/*
||||================================================||||
||||================================================||||
||||    Love Calculator Script By Mohammed Cha      ||||
||||================================================||||
||||================================================||||
*/
?>